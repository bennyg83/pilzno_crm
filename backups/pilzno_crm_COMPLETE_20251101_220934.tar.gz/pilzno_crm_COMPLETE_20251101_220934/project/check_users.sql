SELECT id, email, "firstName", "lastName", role, "isActive" 
FROM users 
ORDER BY "createdAt";
